<?php
include('../db/connection.php');

$result = $conn->query("SELECT * FROM pedidos");
$pedidos = array();

while($row = $result->fetch_assoc()) {
    $pedidos[] = $row;
}

echo json_encode($pedidos);

$conn->close();
?>
