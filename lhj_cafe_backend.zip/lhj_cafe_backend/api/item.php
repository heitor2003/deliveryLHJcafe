<?php
include('../db/connection.php');

$result = $conn->query("SELECT * FROM itens");
$itens = array();

while($row = $result->fetch_assoc()) {
    $itens[] = $row;
}

echo json_encode($itens);

$conn->close();
?>
