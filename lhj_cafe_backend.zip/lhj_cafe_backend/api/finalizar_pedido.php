<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Conexão com o banco de dados
require_once '../db/connection.php';

try {
    // Decodifica o corpo da requisição
    $data = json_decode(file_get_contents('php://input'), true);

    // Insere um novo pedido na tabela pedidos
    $stmt = $conn->prepare("INSERT INTO pedidos (data_pedido, hora_pedido) VALUES (?, ?)");
    $stmt->bind_param("ss", date('Y-m-d'), date('H:i:s'));
    $stmt->execute();
    $pedido_id = $stmt->insert_id;
    
    // Insere os itens do pedido na tabela itens_pedido
    $stmt = $conn->prepare("INSERT INTO itens_pedido (item_id, pedido_id, quantidade, valor_total) VALUES (?, ?, ?, ?)");
    foreach ($data['items'] as $item) {
        $stmt->bind_param("iiid", $item['id'], $pedido_id, $item['quantity'], $item['value']);
        $stmt->execute();
    }

    // Confirma a transação
    $conn->commit();

    echo json_encode(['status' => 'success', 'message' => 'Pedido finalizado com sucesso!']);
} catch (Exception $e) {
    // Desfaz a transação em caso de erro
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
