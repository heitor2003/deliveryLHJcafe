<?php
$servername = "localhost";
$username = "heitor";
$password = "password"; 
$dbname = "delivery_lhj_cafe";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Checa a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
